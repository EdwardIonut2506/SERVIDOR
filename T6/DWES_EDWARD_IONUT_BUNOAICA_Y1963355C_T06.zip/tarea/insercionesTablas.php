<?php

    $conn = new mysqli("localhost", "root", "foc_formacion", "libros");


    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }


    $q1 = "INSERT INTO autor (id, nombre, apellidos, nacionalidad) VALUES 
    (1, 'J. R. R.', 'Tolkien', 'Inglaterra')";

    $q2 = "INSERT INTO autor (id, nombre, apellidos, nacionalidad) VALUES 
    (2, 'Isaac', 'Asimov', 'Rusia')";


    if ($conn->query($q1) === TRUE) {
        echo "Datos insertados correctamente en la tabla libros";
    } else {
        echo "Error al insertar datos en la tabla libros: " . $conn->error;
    }

    if ($conn->query($q2) === TRUE) {
        echo "Datos insertados correctamente en la tabla libros";
    } else {
        echo "Error al insertar datos en la tabla libros: " . $conn->error;
    }


    $conn->close();
?>