<?php

    $conn = new mysqli("localhost", "root", "foc_formacion", "libros");

    if ($conn->connect_error) {
        die("Error de conexión: " . $conn->connect_error);
    }

    $query_libros = "
        INSERT INTO libro (id, titulo, f_publicacion, id_autor) VALUES
        (1, 'El Hobbit', '1937-09-21', 1),
        (2, 'La Comunidad del Anillo', '1954-07-29', 1),
        (3, 'Las dos torres', '1954-11-11', 1),
        (4, 'El retorno del Rey', '1955-10-20', 1),
        (5, 'Un guijarro en el cielo', '1950-01-19', 2),
        (6, 'Fundación', '1951-06-01', 2),
        (7, 'Yo, robot', '1950-12-02', 2);
    ";

    if ($conn->query($query_libros) === TRUE) {
        echo "Datos insertados correctamente en la tabla libro";
    } else {
        echo "Error al insertar datos en la tabla libro: " . $conn->error;
    }

    $conn->close();
?>
