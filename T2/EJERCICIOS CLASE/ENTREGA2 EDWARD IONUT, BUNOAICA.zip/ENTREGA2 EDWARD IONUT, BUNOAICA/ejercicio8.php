<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EJERCICIO 8</title>
</head>
<body>
    <header>
        <h1>Ejercicio 8, Numeros aleatorios</h1>
    </header>

    <p>
        <?php 
            echo rand(0,100);
        ?>
    </p>
    
</body>
</html>