<style>
    header{
        color: gray;
    }
</style>
<header>
    <h1>Evo-Tech</h1>
    <h3><strong>"Tenemos lo mejor, para los mejores"</strong></h3>
</header>