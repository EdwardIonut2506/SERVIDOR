<style>
    footer{
        background-color: black;
        position: relative;
        bottom: 0;
        width: 100%;
        height: 40px;
        color: lightgrey;
    }
    p{
        color: gray;
    }
</style>
<footer>
    <p><strong>Todos los derechos reservados EVO-TECH 2024</strong></p>
</footer>