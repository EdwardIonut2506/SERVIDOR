<nav>
    <ul>
        <li><a href="paginaPrincipal.php">Inicio</a></li>
        <li><a href="paginaImagenes.php">Catalogo</a></li>
    </ul>
</nav>