<?php
    session_start();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $usuarios = [
            ['usuario' => 'admin', 'contraseña' => 'admin123', 'rol' => 'administrador'],
            ['usuario' => 'user', 'contraseña' => 'user123', 'rol' => 'usuario']
        ];

        $usuario_ingresado = $_POST['usuario'];
        $contraseña_ingresada = $_POST['contraseña'];

        foreach ($usuarios as $usuario) {
            if ($usuario['usuario'] === $usuario_ingresado && $usuario['contraseña'] === $contraseña_ingresada) {
                $_SESSION['usuario'] = $usuario_ingresado;
                $_SESSION['rol'] = $usuario['rol'];

                if ($usuario['rol'] === 'administrador') {
                    header('Location: admin.php');
                } else {
                    header('Location: user.php');
                }
                exit();
            }
        }
        $error = "Credenciales incorrectas";
    }
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio de Sesión</title>
</head>
<body>
    <h1>Iniciar Sesión</h1>
    <?php if (isset($error)): ?>
        <p style="color: red;"><?= $error ?></p>
    <?php endif; ?>
    <form method="POST">
        <label for="usuario">Usuario:</label><br>
        <input type="text" id="usuario" name="usuario" required><br><br>

        <label for="contraseña">Contraseña:</label><br>
        <input type="password" id="contraseña" name="contraseña" required><br><br>

        <button type="submit">Iniciar Sesión</button>
    </form>
</body>
</html>
