<?php
session_start();
if (isset($_SESSION['usuario'])) {
    header("Location: sesion.php");
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $usuario = $_POST['usuario'];
    $contraseña = $_POST['contraseña'];
    if ($usuario === 'foc' && $contraseña === 'Fdwes!22') {
        $_SESSION['usuario'] = $usuario;
        header("Location: sesion.php");
        exit();
    } else {
        $error = 'Credenciales incorrectas';
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>

<h2>Iniciar sesión</h2>

<?php
if ($error) {
    echo "<p style='color: red;'>$error</p>";
}
?>

<form action="login.php" method="POST">
    <label for="usuario">Usuario:</label>
    <input type="text" id="usuario" name="usuario" required>
    <br><br>
    <label for="contraseña">Contraseña:</label>
    <input type="password" id="contraseña" name="contraseña" required>
    <br><br>
    <input type="submit" value="Iniciar sesión">
</form>

</body>
</html>
